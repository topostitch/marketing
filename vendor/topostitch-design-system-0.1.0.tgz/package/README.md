# TopoStitch Design System

Local source repository for `@topostitch/design-system`. No remote repository or public package has been created yet.

- Notion defines principles: [Brand Guidelines](https://www.notion.so/3a0401b87b6b81dc9176fc7456b061c2), [RFC-0023](https://www.notion.so/3ac401b87b6b81d38ab8f2ffc51c7ee0).
- [Figma](https://www.figma.com/design/GMj1qinHGe87lxVh1ryibV) defines reviewed visual assets and variables.
- `tokens/tokens.json` is the versioned implementation snapshot. Generated CSS is never hand-edited.
- Storybook demonstrates executable components and states. It is not a second styling source.

## Development

`npm ci`, `npm run build`, `npm run check`, `npm run storybook`.

`npm run build-storybook` creates a static review site. The Design tab links to Figma.

## Design changes

Edit semantic variables in Figma, export with the provided local plugin, then run `npm run figma:import -- /absolute/path/to/export.json` to preview; add `--write` to apply. The local plugin setup is documented in `figma/variable-exporter/README.md`. Review the resulting diff, run checks, inspect light/dark components in Storybook, and run `npm run build` and `npm pack`.

Consumers install a versioned tarball in `vendor/` for reproducible independent builds until a private registry or remote is selected. Copy the new tarball into each consumer and install with `npm install ./vendor/topostitch-design-system-VERSION.tgz`. Never rely on an absolute local folder dependency in a deployed app.

Figma variable changes can update supported colors, numeric type sizes, spacing, radii, and motion. A different font family needs a licensed font deployment and approved fallback stack. Component structure, interactions, responsive rules, and new variants require code changes and Storybook review. Logo updates are reviewed SVG replacements. Nothing auto-deploys.

## Baseline decision — 2026-09-27

Jacob selected preservation of the current marketing site. The warm paper/Archive Blue palette and Newsreader/IBM Plex Sans pairing in Notion are future directions, not active production changes. The current marketing typography uses the OS sans-serif stack (SF Pro on macOS); the platform declares Inter then system fallbacks. Figma documents that distinction.

The platform has existing uncommitted feature work. Integration must preserve it and use a narrowly scoped compatibility bridge rather than re-theme the whole app.

## Release boundaries

This is an initial shared foundation, not a claim that every existing platform screen has been migrated. The integration inventory records which consumers use shared tokens/components. Figma Code Connect is distinct from Storybook linking and may require an Organization/Enterprise plan plus published library components; do not claim it is active without verification.

## Figma font availability

SF Pro is listed by the connector but reports missing fonts when rendered. Documentation labels use Inter. The marketing site keeps its system-font stack; Figma preview-font choice is pending approval. Typography samples label the preview explicitly.
